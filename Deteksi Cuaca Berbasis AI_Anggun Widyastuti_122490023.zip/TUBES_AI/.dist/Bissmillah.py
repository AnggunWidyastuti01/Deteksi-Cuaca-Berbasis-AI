import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import joblib

# Global variabel
model = None
X_test, y_test, label_map = None, None, None
df = None

# Load dan preprocessing data
def preprocessing_data():
    global df, label_map
    file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    if file_path:
        df = pd.read_excel(file_path)
        df.dropna(inplace=True)
        label_map = {label: idx for idx, label in enumerate(df['Cuaca'].unique())}
        df['Cuaca'] = df['Cuaca'].map(label_map)
        messagebox.showinfo("Preprocessing", "Preprocessing berhasil!")

def load_and_train():
    global model, X_test, y_test, df
    if df is not None:
        features = ['Suhu (\u00b0C)', 'Kelembapan (%)', 'Tekanan (hPa)', 'Curah Hujan (mm)', 'Kecepatan Angin (m/s)']
        X = df[features]
        y = df['Cuaca']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        model.fit(X_train, y_train)
        messagebox.showinfo("Training", "Model berhasil dilatih!")
    else:
        messagebox.showwarning("Warning", "Data belum dipreprocessing!")

def save_model():
    if model:
        joblib.dump(model, "model_cuaca.pkl")
        messagebox.showinfo("Simpan Model", "Model berhasil disimpan!")

def evaluate_model():
    global model, X_test, y_test, label_map
    if model:
        y_pred = model.predict(X_test)
        report = classification_report(y_test, y_pred, target_names=label_map.keys())
        eval_text.delete('1.0', tk.END)
        eval_text.insert(tk.END, report)

        fig, ax = plt.subplots(figsize=(5, 4))
        disp = ConfusionMatrixDisplay(confusion_matrix(y_test, y_pred), display_labels=label_map.keys())
        disp.plot(ax=ax)
        ax.set_title("Confusion Matrix")
        for widget in cm_frame.winfo_children(): widget.destroy()
        canvas = FigureCanvasTkAgg(fig, master=cm_frame)
        canvas.draw()
        canvas.get_tk_widget().pack()

# Prediksi input manual
def classify_input():
    global model, label_map
    try:
        data = [[float(suhu_var.get()), float(kelembapan_var.get()), float(tekanan_var.get()),
                 float(hujan_var.get()), float(angin_var.get())]]
        pred = model.predict(data)[0]
        hasil_pred.set(list(label_map.keys())[list(label_map.values()).index(pred)])
    except Exception as e:
        messagebox.showerror("Error", f"Input tidak valid! {e}")

# GUI
app = tk.Tk()
app.title("Prediksi Cuaca AI")
notebook = ttk.Notebook(app)
notebook.pack(expand=True, fill='both')

# Tab Preprocessing
frame_pre = ttk.Frame(notebook)
notebook.add(frame_pre, text='Preprocessing')
tk.Button(frame_pre, text="Muat dan Preprocessing Data Cuaca", command=preprocessing_data).pack(pady=20)

# Tab Training
frame_training = ttk.Frame(notebook)
notebook.add(frame_training, text='Training')
tk.Button(frame_training, text="Mulai Training", command=load_and_train).pack(pady=10)
tk.Button(frame_training, text="Simpan Model", command=save_model).pack(pady=10)

# Tab Evaluasi
frame_eval = ttk.Frame(notebook)
notebook.add(frame_eval, text='Evaluasi')
tk.Button(frame_eval, text="Evaluasi Model", command=evaluate_model).pack()
eval_text = tk.Text(frame_eval, height=15, width=80)
eval_text.pack()
cm_frame = tk.Frame(frame_eval)
cm_frame.pack()

# Tab Klasifikasi
frame_klasifikasi = ttk.Frame(notebook)
notebook.add(frame_klasifikasi, text='Klasifikasi')
tk.Label(frame_klasifikasi, text="Suhu (\u00b0C)").grid(row=0, column=0)
suhu_var = tk.StringVar()
tk.Entry(frame_klasifikasi, textvariable=suhu_var).grid(row=0, column=1)

tk.Label(frame_klasifikasi, text="Kelembapan (%)").grid(row=1, column=0)
kelembapan_var = tk.StringVar()
tk.Entry(frame_klasifikasi, textvariable=kelembapan_var).grid(row=1, column=1)

tk.Label(frame_klasifikasi, text="Tekanan (hPa)").grid(row=2, column=0)
tekanan_var = tk.StringVar()
tk.Entry(frame_klasifikasi, textvariable=tekanan_var).grid(row=2, column=1)

tk.Label(frame_klasifikasi, text="Curah Hujan (mm)").grid(row=3, column=0)
hujan_var = tk.StringVar()
tk.Entry(frame_klasifikasi, textvariable=hujan_var).grid(row=3, column=1)

tk.Label(frame_klasifikasi, text="Kecepatan Angin (m/s)").grid(row=4, column=0)
angin_var = tk.StringVar()
tk.Entry(frame_klasifikasi, textvariable=angin_var).grid(row=4, column=1)

# ComboBox Arah Angin dan Waktu
arah_var = tk.StringVar()
date_var = tk.StringVar()
tk.Label(frame_klasifikasi, text="Arah Angin").grid(row=5, column=0)
ttk.Combobox(frame_klasifikasi, textvariable=arah_var, values=["Utara", "Timur", "Selatan", "Barat", "Tenggara", "Barat Laut"]).grid(row=5, column=1)

tk.Label(frame_klasifikasi, text="Tanggal dan Waktu").grid(row=6, column=0)
ttk.Combobox(frame_klasifikasi, textvariable=date_var, values=["Pagi", "Siang", "Sore", "Malam"]).grid(row=6, column=1)

tk.Button(frame_klasifikasi, text="Prediksi Cuaca", command=classify_input).grid(row=7, columnspan=2, pady=10)

hasil_pred = tk.StringVar()
tk.Label(frame_klasifikasi, textvariable=hasil_pred, font=('Helvetica', 16)).grid(row=8, columnspan=2)

app.mainloop()