import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (classification_report, confusion_matrix, 
                            ConfusionMatrixDisplay, accuracy_score,
                            precision_score, recall_score, f1_score,
                            roc_auc_score)
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import joblib
from datetime import datetime
import numpy as np
from sklearn import tree
import os

# Global variables
model = None
X_test, y_test, label_map = None, None, None
df = None
saved_models = {}  # Dictionary untuk menyimpan model yang telah disimpan

# Load and preprocess data
def preprocessing_data():
    global df, label_map
    file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
    if file_path:
        df = pd.read_excel(file_path)
        df.dropna(inplace=True)
        label_map = {label: idx for idx, label in enumerate(df['Cuaca'].unique())}
        df['Cuaca'] = df['Cuaca'].map(label_map)
        messagebox.showinfo("Preprocessing", "Preprocessing berhasil!")

def load_and_train():
    global model, X_test, y_test, df
    if df is not None:
        features = ['Suhu (\u00b0C)', 'Kelembapan (%)', 'Tekanan (hPa)', 'Curah Hujan (mm)', 'Kecepatan Angin (m/s)']
        X = df[features]
        y = df['Cuaca']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        model.fit(X_train, y_train)
        messagebox.showinfo("Training", "Model berhasil dilatih!")
    else:
        messagebox.showwarning("Warning", "Data belum dipreprocessing!")

def load_saved_models():
    global saved_models
    # Cari semua file model di direktori
    model_files = [f for f in os.listdir() if f.endswith('.pkl')]
    saved_models = {}
    for file in model_files:
        try:
            model_name = file.replace('.pkl', '')
            saved_models[model_name] = file
        except:
            continue
    # Update combo box
    model_combo['values'] = list(saved_models.keys())

def save_model():
    global model, saved_models
    if model is None:
        messagebox.showwarning("Warning", "Model belum dilatih!")
        return
        
    # Minta nama model dari user
    model_name = tk.simpledialog.askstring("Simpan Model", 
                                         "Masukkan nama untuk model ini:",
                                         parent=app)
    if model_name:
        # Tambahkan ekstensi .pkl jika belum ada
        if not model_name.endswith('.pkl'):
            model_name += '.pkl'
            
        # Simpan model
        joblib.dump(model, model_name)
        messagebox.showinfo("Simpan Model", f"Model berhasil disimpan sebagai {model_name}")
        
        # Update dictionary dan combo box
        saved_models[model_name.replace('.pkl', '')] = model_name
        model_combo['values'] = list(saved_models.keys())
        
        # Pilih model yang baru disimpan
        model_combo.set(model_name.replace('.pkl', ''))

def load_selected_model():
    global model, X_test, y_test, label_map
    selected_model = model_combo.get()
    if selected_model and selected_model in saved_models:
        try:
            model = joblib.load(saved_models[selected_model])
            messagebox.showinfo("Load Model", f"Model {selected_model} berhasil dimuat!")
        except Exception as e:
            messagebox.showerror("Error", f"Gagal memuat model: {str(e)}")

def evaluate_model():
    global model, X_test, y_test, label_map
    if model:
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)
        
        # Calculate metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, average='weighted')
        recall = recall_score(y_test, y_pred, average='weighted')
        f1 = f1_score(y_test, y_pred, average='weighted')
        
        # For multi-class ROC-AUC
        try:
            if len(label_map) > 2:
                roc_auc = roc_auc_score(y_test, y_prob, multi_class='ovr')
            else:
                roc_auc = roc_auc_score(y_test, y_prob[:, 1])
        except:
            roc_auc = "N/A (requires binary classification or probability estimates)"
        
        # Generate classification report
        report = classification_report(y_test, y_pred, target_names=label_map.keys())
        
        # Create detailed evaluation summary
        summary = (
            "=== HASIL EVALUASI MODEL ===\n\n"
            f"1. AKURASI: {accuracy:.2%}\n"
            f"   - Tingkat prediksi benar secara keseluruhan\n"
            f"   - Semakin tinggi nilai akurasi, semakin baik model dalam memprediksi\n"
            f"   - Nilai {accuracy:.2%} menunjukkan bahwa model benar memprediksi {accuracy:.2%} dari total data\n\n"
            
            f"2. PRESISI: {precision:.2%}\n"
            f"   - Ketepatan prediksi positif (minim false positive)\n"
            f"   - Menunjukkan seberapa tepat model dalam memprediksi kelas tertentu\n"
            f"   - Nilai {precision:.2%} menunjukkan bahwa dari semua prediksi positif, {precision:.2%} benar-benar positif\n\n"
            
            f"3. RECALL: {recall:.2%}\n"
            f"   - Kemampuan menemukan semua kasus positif (minim false negative)\n"
            f"   - Menunjukkan seberapa baik model menemukan semua kasus yang seharusnya positif\n"
            f"   - Nilai {recall:.2%} menunjukkan bahwa model berhasil menemukan {recall:.2%} dari semua kasus yang seharusnya positif\n\n"
            
            f"4. F1-SCORE: {f1:.2%}\n"
            f"   - Keseimbangan antara Precision dan Recall\n"
            f"   - Menggabungkan precision dan recall dalam satu metrik\n"
            f"   - Nilai {f1:.2%} menunjukkan keseimbangan yang {'baik' if f1 > 0.7 else 'perlu ditingkatkan'} antara precision dan recall\n\n"
            
            f"5. ROC-AUC: {roc_auc if isinstance(roc_auc, str) else f'{roc_auc:.2%}'}\n"
            f"   - Kemampuan membedakan antar kelas (1=sempurna, 0.5=acak)\n"
            f"   - Menunjukkan seberapa baik model membedakan antara kelas yang berbeda\n"
            f"   - Nilai {roc_auc if isinstance(roc_auc, str) else f'{roc_auc:.2%}'} menunjukkan kemampuan model yang {'sangat baik' if isinstance(roc_auc, float) and roc_auc > 0.9 else 'baik' if isinstance(roc_auc, float) and roc_auc > 0.7 else 'perlu ditingkatkan'}\n\n"
            
            "=== REKOMENDASI ===\n"
            f"- Model {'cukup baik' if accuracy > 0.7 else 'perlu perbaikan'}\n"
            f"- {'Pertahankan parameter' if accuracy > 0.7 else 'Coba tuning hyperparameter atau tambah data'}\n"
            f"- {'Model sudah cukup handal untuk digunakan' if accuracy > 0.8 else 'Perlu evaluasi lebih lanjut untuk meningkatkan performa'}\n\n"
            
            "=== DETAIL KLASIFIKASI PER KELAS ===\n"
            "Penjelasan metrik per kelas:\n"
            "- Precision: Ketepatan prediksi untuk kelas tersebut\n"
            "- Recall: Kemampuan menemukan semua kasus kelas tersebut\n"
            "- F1-score: Keseimbangan antara precision dan recall untuk kelas tersebut\n"
            "- Support: Jumlah sampel aktual untuk kelas tersebut\n\n"
        ) + report
        
        eval_text.delete('1.0', tk.END)
        eval_text.insert(tk.END, summary)

        # Confusion Matrix
        fig, ax = plt.subplots(figsize=(6, 5))
        disp = ConfusionMatrixDisplay(confusion_matrix(y_test, y_pred), display_labels=label_map.keys())
        disp.plot(ax=ax)
        ax.set_title("Confusion Matrix", fontsize=14)
        ax.text(0.5, -0.15, "(Menunjukkan jumlah prediksi benar dan salah untuk setiap kelas)", 
                ha='center', transform=ax.transAxes, fontsize=10)
        for widget in cm_frame.winfo_children(): widget.destroy()
        canvas = FigureCanvasTkAgg(fig, master=cm_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

# Predict input manually - using DataFrame with column names
def classify_input():
    global model, label_map
    try:
        features = ['Suhu (\u00b0C)', 'Kelembapan (%)', 'Tekanan (hPa)', 'Curah Hujan (mm)', 'Kecepatan Angin (m/s)']
        input_data = pd.DataFrame([[
            float(suhu_var.get()),
            float(kelembapan_var.get()),
            float(tekanan_var.get()),
            float(hujan_var.get()),
            float(angin_var.get())
        ]], columns=features)
        pred = model.predict(input_data)[0]
        
        # Format hasil prediksi
        datetime_str = get_selected_datetime()
        if datetime_str:
            result = (
                f"Parameter:\n"
                f"- Suhu: {suhu_var.get()}°C\n"
                f"- Kelembapan: {kelembapan_var.get()}%\n"
                f"- Tekanan: {tekanan_var.get()} hPa\n"
                f"- Curah Hujan: {hujan_var.get()} mm\n"
                f"- Kecepatan Angin: {angin_var.get()} m/s\n"
                f"- Arah Angin: {arah_var.get()}\n\n"
                f"Tanggal dan Waktu: {datetime_str} WIB\n\n"
                f"Hasil Prediksi: {list(label_map.keys())[list(label_map.values()).index(pred)]}"
            )
        else:
            result = (
                f"Parameter:\n"
                f"- Suhu: {suhu_var.get()}°C\n"
                f"- Kelembapan: {kelembapan_var.get()}%\n"
                f"- Tekanan: {tekanan_var.get()} hPa\n"
                f"- Curah Hujan: {hujan_var.get()} mm\n"
                f"- Kecepatan Angin: {angin_var.get()} m/s\n"
                f"- Arah Angin: {arah_var.get()}\n\n"
                f"Hasil Prediksi: {list(label_map.keys())[list(label_map.values()).index(pred)]}"
            )
        hasil_pred.set(result)
    except Exception as e:
        messagebox.showerror("Error", f"Input tidak valid! {e}")

def get_selected_datetime():
    try:
        day = int(date_var.get())
        hour = int(hour_var.get())
        dt = datetime(2025, 5, day, hour, 0, 0)
        datetime_str = dt.strftime("%Y-%m-%d %H:%M:%S")
        return datetime_str
    except Exception:
        return None

def visualize_decision_tree():
    global model, df
    if model is None:
        messagebox.showwarning("Warning", "Model belum dilatih!")
        return
        
    # Buat jendela baru untuk menampilkan pohon
    tree_window = tk.Toplevel(app)
    tree_window.title("Visualisasi Pohon Keputusan")
    tree_window.geometry("1200x800")
    
    # Buat frame untuk canvas dengan scrollbar
    frame = ttk.Frame(tree_window)
    frame.pack(fill=tk.BOTH, expand=True)
    
    # Buat canvas dengan scrollbar
    canvas = tk.Canvas(frame)
    scrollbar = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
    scrollable_frame = ttk.Frame(canvas)
    
    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
    )
    
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    
    # Ambil pohon pertama dari Random Forest
    estimator = model.estimators_[0]
    
    # Buat visualisasi pohon
    fig = plt.figure(figsize=(15, 20))
    tree.plot_tree(estimator, 
                  feature_names=['Suhu (°C)', 'Kelembapan (%)', 'Tekanan (hPa)', 
                               'Curah Hujan (mm)', 'Kecepatan Angin (m/s)'],
                  class_names=list(label_map.keys()),
                  filled=True, 
                  rounded=True,
                  fontsize=8)
    
    # Tambahkan judul
    plt.title("Pohon Keputusan untuk Prediksi Cuaca", pad=20, fontsize=12)
    
    # Tampilkan di frame yang bisa di-scroll
    canvas_widget = FigureCanvasTkAgg(fig, master=scrollable_frame)
    canvas_widget.draw()
    canvas_widget.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    # Atur scrollbar dan canvas
    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    
    # Tambahkan mouse wheel scrolling
    def _on_mousewheel(event):
        canvas.yview_scroll(int(-1*(event.delta/120)), "units")
    
    canvas.bind_all("<MouseWheel>", _on_mousewheel)
    
    # Tambahkan tombol untuk menyimpan gambar
    def save_tree():
        file_path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG files", "*.png"), ("All files", "*.*")]
        )
        if file_path:
            fig.savefig(file_path, dpi=300, bbox_inches='tight')
            messagebox.showinfo("Sukses", "Gambar pohon keputusan berhasil disimpan!")
    
    # Frame untuk tombol
    button_frame = ttk.Frame(tree_window)
    button_frame.pack(side="bottom", fill="x", padx=5, pady=5)
    
    ttk.Button(button_frame, text="Simpan Gambar", command=save_tree).pack(side="right", padx=5)

# GUI setup
app = tk.Tk()
app.title("Prediksi Cuaca AI")
notebook = ttk.Notebook(app)
notebook.pack(expand=True, fill='both')

# Tab Preprocessing
frame_pre = ttk.Frame(notebook)
notebook.add(frame_pre, text='Preprocessing')
tk.Button(frame_pre, text="Muat dan Preprocessing Data Cuaca", command=preprocessing_data).pack(pady=20)

# Tab Training
frame_training = ttk.Frame(notebook)
notebook.add(frame_training, text='Training')
tk.Button(frame_training, text="Mulai Training", command=load_and_train).pack(pady=10)
tk.Button(frame_training, text="Simpan Model", command=save_model).pack(pady=10)
tk.Button(frame_training, text="Tampilkan Pohon Keputusan", command=visualize_decision_tree).pack(pady=10)

# Tab Evaluasi
frame_eval = ttk.Frame(notebook)
notebook.add(frame_eval, text='Evaluasi')

# Frame untuk pemilihan model
model_frame = ttk.Frame(frame_eval)
model_frame.pack(pady=10)
ttk.Label(model_frame, text="Pilih Model:").pack(side=tk.LEFT, padx=5)
model_combo = ttk.Combobox(model_frame, state="readonly")
model_combo.pack(side=tk.LEFT, padx=5)
ttk.Button(model_frame, text="Muat Model", command=load_selected_model).pack(side=tk.LEFT, padx=5)

# Frame untuk evaluasi (menggunakan grid layout)
eval_frame = ttk.Frame(frame_eval)
eval_frame.pack(fill=tk.BOTH, expand=True, pady=10)

# Frame untuk ringkasan evaluasi (kiri)
summary_frame = ttk.Frame(eval_frame)
summary_frame.grid(row=0, column=0, padx=10, sticky="nsew")

# Frame untuk confusion matrix (kanan)
cm_frame = ttk.Frame(eval_frame)
cm_frame.grid(row=0, column=1, padx=10, sticky="nsew")

# Konfigurasi grid weights
eval_frame.grid_columnconfigure(0, weight=3)  # Ringkasan lebih lebar
eval_frame.grid_columnconfigure(1, weight=2)  # Confusion matrix lebih sempit
eval_frame.grid_rowconfigure(0, weight=1)

# Tombol evaluasi dan text area untuk ringkasan
tk.Button(summary_frame, text="Evaluasi Model", command=evaluate_model).pack(pady=5)
eval_text = tk.Text(summary_frame, height=30, width=70)  # Ukuran disesuaikan
eval_text.pack(fill=tk.BOTH, expand=True)

# Tab Klasifikasi
frame_klasifikasi = ttk.Frame(notebook)
notebook.add(frame_klasifikasi, text='Klasifikasi')

# Frame utama untuk konten
main_frame = ttk.Frame(frame_klasifikasi)
main_frame.pack(expand=True, pady=20)

# Frame untuk input fields
input_frame = ttk.Frame(main_frame)
input_frame.pack(pady=10)

# Input fields dengan grid layout
tk.Label(input_frame, text="Suhu (\u00b0C)").grid(row=0, column=0, sticky='e', padx=5, pady=5)
suhu_var = tk.StringVar()
tk.Entry(input_frame, textvariable=suhu_var, width=15).grid(row=0, column=1, padx=5, pady=5)

tk.Label(input_frame, text="Kelembapan (%)").grid(row=1, column=0, sticky='e', padx=5, pady=5)
kelembapan_var = tk.StringVar()
tk.Entry(input_frame, textvariable=kelembapan_var, width=15).grid(row=1, column=1, padx=5, pady=5)

tk.Label(input_frame, text="Tekanan (hPa)").grid(row=2, column=0, sticky='e', padx=5, pady=5)
tekanan_var = tk.StringVar()
tk.Entry(input_frame, textvariable=tekanan_var, width=15).grid(row=2, column=1, padx=5, pady=5)

tk.Label(input_frame, text="Curah Hujan (mm)").grid(row=3, column=0, sticky='e', padx=5, pady=5)
hujan_var = tk.StringVar()
tk.Entry(input_frame, textvariable=hujan_var, width=15).grid(row=3, column=1, padx=5, pady=5)

tk.Label(input_frame, text="Kecepatan Angin (m/s)").grid(row=4, column=0, sticky='e', padx=5, pady=5)
angin_var = tk.StringVar()
tk.Entry(input_frame, textvariable=angin_var, width=15).grid(row=4, column=1, padx=5, pady=5)

# ComboBox Arah Angin
arah_var = tk.StringVar()
tk.Label(input_frame, text="Arah Angin").grid(row=5, column=0, sticky='e', padx=5, pady=5)
ttk.Combobox(input_frame, textvariable=arah_var, values=["Utara", "Timur", "Selatan", "Barat", "Tenggara", "Barat Laut"], width=12).grid(row=5, column=1, padx=5, pady=5)

# Frame untuk tanggal dan jam
datetime_frame = ttk.Frame(main_frame)
datetime_frame.pack(pady=10)

# Date and Hour selection
tk.Label(datetime_frame, text="Tanggal").grid(row=0, column=0, sticky='e', padx=5, pady=5)
date_var = tk.StringVar()
date_choices = [str(i) for i in range(1, 32)]
ttk.Combobox(datetime_frame, textvariable=date_var, values=date_choices, width=5).grid(row=0, column=1, sticky='w', padx=5, pady=5)

tk.Label(datetime_frame, text="Jam").grid(row=0, column=2, sticky='e', padx=5, pady=5)
hour_var = tk.StringVar()
hour_choices = [str(i) for i in range(0, 24)]
ttk.Combobox(datetime_frame, textvariable=hour_var, values=hour_choices, width=5).grid(row=0, column=3, sticky='w', padx=5, pady=5)

tk.Label(datetime_frame, text="Bulan/Tahun").grid(row=0, column=4, sticky='e', padx=5, pady=5)
tk.Label(datetime_frame, text="Mei/2025").grid(row=0, column=5, sticky='w', padx=5, pady=5)

# Button to Predict Weather
predict_button = tk.Button(main_frame, text="Prediksi Cuaca", command=classify_input, width=15)
predict_button.pack(pady=20)

# Modifikasi frame hasil prediksi
result_frame = ttk.Frame(main_frame)
result_frame.pack(pady=10, expand=True, fill='both')
result_frame.grid_columnconfigure(0, weight=1)

# Label untuk hasil prediksi dengan grid layout
hasil_pred = tk.StringVar()
result_label = tk.Label(result_frame, textvariable=hasil_pred, font=('Helvetica', 12), justify=tk.CENTER, wraplength=400)
result_label.grid(row=0, column=0, padx=10, pady=5)

# Frame untuk grid layout hasil
grid_frame = ttk.Frame(result_frame)
grid_frame.grid(row=1, column=0, padx=10, pady=5, sticky='nsew')

# Fungsi untuk membuat grid hasil
def create_result_grid():
    for widget in grid_frame.winfo_children():
        widget.destroy()
    
    # Konfigurasi grid frame
    grid_frame.grid_columnconfigure(0, weight=1)
    grid_frame.grid_columnconfigure(1, weight=1)
    
    # Style untuk frame dengan border
    style = ttk.Style()
    style.configure('Bordered.TFrame', borderwidth=2, relief='solid')
    
    # Frame utama dengan border
    main_grid = ttk.Frame(grid_frame, style='Bordered.TFrame')
    main_grid.grid(row=0, column=0, columnspan=2, padx=10, pady=5, sticky='nsew')
    
    # Header dengan background
    header_frame = ttk.Frame(main_grid)
    header_frame.grid(row=0, column=0, columnspan=2, sticky='ew')
    header_frame.grid_columnconfigure(0, weight=1)
    header_frame.grid_columnconfigure(1, weight=1)
    
    # Header labels
    ttk.Label(header_frame, text="Parameter", font=('Helvetica', 10, 'bold')).grid(row=0, column=0, padx=5, pady=2, sticky='ew')
    ttk.Label(header_frame, text="Nilai", font=('Helvetica', 10, 'bold')).grid(row=0, column=1, padx=5, pady=2, sticky='ew')
    
    # Separator setelah header
    ttk.Separator(main_grid, orient='horizontal').grid(row=1, column=0, columnspan=2, sticky='ew', padx=5)
    
    # Data
    parameters = [
        ("Suhu", f"{suhu_var.get()}°C"),
        ("Kelembapan", f"{kelembapan_var.get()}%"),
        ("Tekanan", f"{tekanan_var.get()} hPa"),
        ("Curah Hujan", f"{hujan_var.get()} mm"),
        ("Kecepatan Angin", f"{angin_var.get()} m/s"),
        ("Arah Angin", arah_var.get())
    ]
    
    # Frame untuk parameter
    param_frame = ttk.Frame(main_grid)
    param_frame.grid(row=2, column=0, columnspan=2, sticky='ew')
    param_frame.grid_columnconfigure(0, weight=1)
    param_frame.grid_columnconfigure(1, weight=1)
    
    for i, (param, value) in enumerate(parameters):
        # Frame untuk setiap baris
        row_frame = ttk.Frame(param_frame)
        row_frame.grid(row=i, column=0, columnspan=2, sticky='ew')
        row_frame.grid_columnconfigure(0, weight=1)
        row_frame.grid_columnconfigure(1, weight=1)
        
        # Label parameter dan nilai
        ttk.Label(row_frame, text=param).grid(row=0, column=0, padx=5, pady=2, sticky='ew')
        ttk.Label(row_frame, text=value).grid(row=0, column=1, padx=5, pady=2, sticky='ew')
        
        # Separator antar baris
        if i < len(parameters) - 1:
            ttk.Separator(param_frame, orient='horizontal').grid(row=i+1, column=0, columnspan=2, sticky='ew', padx=5)
    
    # Separator sebelum tanggal
    ttk.Separator(main_grid, orient='horizontal').grid(row=3, column=0, columnspan=2, sticky='ew', padx=5)
    
    # Tanggal dan Waktu
    datetime_str = get_selected_datetime()
    if datetime_str:
        date_frame = ttk.Frame(main_grid)
        date_frame.grid(row=4, column=0, columnspan=2, sticky='ew')
        date_frame.grid_columnconfigure(0, weight=1)
        date_frame.grid_columnconfigure(1, weight=1)
        
        ttk.Label(date_frame, text="Tanggal dan Waktu", font=('Helvetica', 10, 'bold')).grid(row=0, column=0, padx=5, pady=2, sticky='ew')
        ttk.Label(date_frame, text=f"{datetime_str} WIB").grid(row=0, column=1, padx=5, pady=2, sticky='ew')
    
    # Separator sebelum hasil prediksi
    ttk.Separator(main_grid, orient='horizontal').grid(row=5, column=0, columnspan=2, sticky='ew', padx=5)
    
    # Hasil Prediksi
    pred_frame = ttk.Frame(main_grid)
    pred_frame.grid(row=6, column=0, columnspan=2, sticky='ew')
    pred_frame.grid_columnconfigure(0, weight=1)
    pred_frame.grid_columnconfigure(1, weight=1)
    
    ttk.Label(pred_frame, text="Hasil Prediksi", font=('Helvetica', 10, 'bold')).grid(row=0, column=0, padx=5, pady=2, sticky='ew')
    ttk.Label(pred_frame, text=hasil_pred.get().split("Hasil Prediksi: ")[-1]).grid(row=0, column=1, padx=5, pady=2, sticky='ew')

# Load saved models saat aplikasi dimulai
load_saved_models()

app.mainloop()